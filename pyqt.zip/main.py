import os
import time

from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMessageBox, QMainWindow, QFileDialog
from PyQt5.QtCore import QTimer
from core.get_device import *
from ui.main import Ui_MainWindow
from threading import Thread
from queue import Queue
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas


class MainWindow(Ui_MainWindow, QMainWindow):

    def __init__(self,  *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)
        self.setupUi(self)  # 初始化ui

        self.api = {}
        self.device = {}
        self.current_in = []
        self.current_out = []
        self.msg_queue = Queue()
        self.x = []
        self.process = 0
        self.index = None
        p = Thread(target=self.thread_deal, daemon=True)
        p.start()
        self.init_ui()
        self.connect_fun()
        self.deal_timer = QTimer(self)
        self.deal_timer.timeout.connect(self.thread_deal)
        self.create_figures()
        self.ax = self.figure.add_axes([0.1, 0.1, 0.8, 0.8])


        # self.show_table([1, 2], numpy.array([[1, 2], [2, 3]]))

    def init_ui(self):
        all_api = get_all_api()
        for i in all_api:
            self.comboBox.addItem(i["name"])
            print(i)
            self.api[i["name"]] = i
        self.device = all_device()
        if all_api:
            self.add_info(self.api[all_api[0]["name"]])
        self.progressBar.setRange(0, 100)
        self.progressBar.setValue(0)

    def connect_fun(self):
        self.comboBox.currentTextChanged.connect(self.show_api_info)
        self.pushButton.clicked.connect(self.play_wav)
        self.pushButton_3.clicked.connect(self.getfile)
        self.pushButton_2.clicked.connect(self.stop_play)

    # 创建matplotlib的画布
    def create_figures(self):
        self.figure = plt.figure()
        self.canvas = FigureCanvas(self.figure)
        self.verticalLayout_4.insertWidget(0, self.canvas)

    def stop_play(self):
        self.index = None
        self.x = []
        stop()
        self.deal_timer.stop()

    def show_table(self, x, y):
        if self.index is not None:
            # self.ax.cla()
            self.ax.set_ylim(-1, 1)
            color = ["b", "g"]
            # self.deal_timer.start(int(self.x[0]) + 20)
            # self.progressBar.setValue(self.process)
            for col in range(y.shape[1]):
                try:
                    self.ax.plot(x, y[:, col], c=color[col])
                except Exception as e:
                    print(e)
            self.canvas.draw()

    def thread_deal(self):
        if self.msg_queue.queue:
            data, x, y = self.msg_queue.get()
            self.process = int(data)
            # if self.index is None:
            #     self.index = y
            #     self.x = x
            # else:
            #     self.index = numpy.append(self.index, numpy.array([[min(y[:, 0]), min(y[:, 1], )],
            #                                                        [max(y[:, 0]), max(y[:, 1])]]), axis=0)
            #     self.x.append(max(x))
            #     self.x.append(max(x))
            self.index = numpy.array([[min(y[:, 0]), min(y[:, 1], )],
                                      [max(y[:, 0]), max(y[:, 1])]])
            self.x = [x[-1], x[-1]]
            self.show_table()
            # self.x = self.x[-100:]
            # self.index = self.index[-100:]

    def getfile(self):
        file_name, file_type = QFileDialog.getOpenFileName(self, "打开wav文件", self.textEdit.toPlainText(),
                                                           "音频文件 (*.wav)")
        self.textEdit.setText(file_name)

    def show_api_info(self, string):
        self.comboBox_2.clear()
        self.current_in.clear()
        self.comboBox_3.clear()
        self.current_out.clear()
        self.add_info(self.api[string])

    def add_info(self, api):
        self.current_in = []
        self.current_out = []
        for j in api["devices"]:
            if self.device[j]["max_in"] > 0:
                self.comboBox_2.addItem("id:{} {}".format(j, self.device[j]["name"]))
                self.current_in.append(j)
            if self.device[j]["maxout"] > 0:
                self.comboBox_3.addItem("id:{} {}".format(j, self.device[j]["name"]))
                self.current_out.append(j)
        if api["default_input_device"] > -1:
            self.comboBox_2.setCurrentIndex(self.current_in.index(api["default_input_device"]))
        if api["default_output_device"] > -1:
            self.comboBox_3.setCurrentIndex(self.current_out.index(api["default_output_device"]))

    def play_wav(self):
        if not self.textEdit.toPlainText().strip() or not os.path.exists(self.textEdit.toPlainText().strip()):
            return
        p = Thread(target=play_wav, args=(self.textEdit.toPlainText().strip(),
                                          self.current_out[self.comboBox_3.currentIndex()], self.msg_queue),
                   daemon=True)
        p.start()
        self.deal_timer.start(1)


if __name__ == "__main__":
    app = QApplication([])
    app.setWindowIcon(QIcon('static/img/ico.png'))
    win = MainWindow()
    win.resize(1500, 600)
    win.show()
    app.exec_()