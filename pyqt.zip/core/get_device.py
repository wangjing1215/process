import time

import sounddevice as sd
import soundfile
import re
import numpy
from queue import Queue
import threading


def get_all_api():
    return sd.query_hostapis()


def all_device():
    dev = sd.query_devices()
    devices = re.findall(r'([<>]*?)\s+(\d+) ([\s\S]*?) ([\s\S]*?),*? ([\s\S]*?) \((\d+) in, (\d+) out\)', repr(dev))
    all_devices = {}
    for i in devices:
        all_devices[int(i[1])] = {"name": i[2] + i[3] + i[4], "max_in": int(i[5]), "maxout": int(i[6]),
                                  "default_in": i[0] == ">",
                                  "default_out": i[0] == "<"}
    return all_devices


def process(all_nums, q, times, out_response):
    current = 0
    while True:
        try:
            res = q.get(timeout=120)
            data = res["data"]
            frames = res["frames"]
            report = (current / all_nums) * 100
            out_response.put((report, times[current:current + frames], data))
            current += frames
            if current >= all_nums:
                out_response.put((report, times[current:current + frames], 100))
                break
        except Exception as e:
            return e


def play_wav(file_path, out_id, out_response):
    data_array, sample_rate = soundfile.read(file_path)
    sd.default.device[1] = out_id  # 这里要配置ASIO唯一那个索引id, 本机是48
    times = [(i + 1) * ((len(data_array) / sample_rate) / len(data_array)) for i in range(len(data_array))]
    deal_queue = Queue()
    threading.Thread(target=process, args=(len(data_array), deal_queue, times, out_response), daemon=True).start()
    play_raw(data_array, blocking=True, samplerate=sample_rate, mapping=None, response=deal_queue)
    # p = Process(target=play_raw, args=(data_array, sample_rate, None, True, False, deal_queue), daemon=True)
    # p.start()
    # p.join()


def stop():
    sd.stop()


def play_raw(data, samplerate=None, mapping=None, blocking=False, loop=False, response=None, **kwargs):
    def callback(outdata, frames, times, status):
        response.put({"data": outdata, "frames": frames})
        assert len(outdata) == frames
        ctx.callback_enter(status, outdata)
        ctx.write_outdata(outdata)
        ctx.callback_exit()
    ctx = sd._CallbackContext(loop=loop)
    ctx.frames = ctx.check_data(data, mapping, kwargs.get('device'))
    ctx.start_stream(sd.OutputStream, samplerate, ctx.output_channels,
                     ctx.output_dtype, callback, blocking,
                     prime_output_buffers_using_stream_callback=False,
                     **kwargs)